class Menu {
  int id;
  String productName;
  String type;
  String details;
  String price;
  String imageUrl;
  int likeCount;
  int stock;
  List<String> sizes;

  Menu({
    required this.id,
    required this.productName,
    required this.type,
    required this.details,
    required this.price,
    required this.imageUrl,
    required this.likeCount,
    required this.stock,
    required this.sizes,
  });
}